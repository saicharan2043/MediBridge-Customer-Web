import { useState } from 'react';
import { SidebarProvider } from '@/components/ui/sidebar';
import { AdminSidebar } from '@/components/admin-sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Pill, 
  Plus, 
  Search, 
  CheckCircle, 
  XCircle, 
  Edit,
  Trash2,
  AlertCircle
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const genericsData = [
  {
    id: "GEN001",
    name: "Paracetamol",
    category: "Analgesic",
    strengths: ["500mg", "650mg", "1000mg"],
    brands: ["Crocin", "Dolo", "Panadol", "Calpol"],
    status: "active"
  },
  {
    id: "GEN002", 
    name: "Amoxicillin",
    category: "Antibiotic",
    strengths: ["250mg", "500mg", "875mg"],
    brands: ["Amoxil", "Moxikind", "Novamox"],
    status: "active"
  },
  {
    id: "GEN003",
    name: "Omeprazole", 
    category: "Proton Pump Inhibitor",
    strengths: ["20mg", "40mg"],
    brands: ["Omez", "Prilosec", "Zegerid"],
    status: "active"
  },
  {
    id: "GEN004",
    name: "Cetirizine",
    category: "Antihistamine", 
    strengths: ["5mg", "10mg"],
    brands: ["Zyrtec", "Alerid", "Okacet"],
    status: "active"
  }
];

const suggestedMedicines = [
  {
    id: "SUG001",
    genericName: "Metformin",
    brandName: "Glucophage", 
    strength: "500mg",
    category: "Antidiabetic",
    suggestedBy: "Dr. Ramesh Gupta - HealthCare Plus",
    suggestedAt: "2024-01-15",
    status: "pending"
  },
  {
    id: "SUG002",
    genericName: "Atorvastatin",
    brandName: "Lipitor",
    strength: "20mg", 
    category: "Statin",
    suggestedBy: "Sunita Sharma - MediLife",
    suggestedAt: "2024-01-14",
    status: "pending"
  },
  {
    id: "SUG003",
    genericName: "Losartan",
    brandName: "Cozaar",
    strength: "50mg",
    category: "ARB",
    suggestedBy: "Apollo Pharmacy",
    suggestedAt: "2024-01-13", 
    status: "approved"
  }
];

export default function MedicineMaster() {
  const [generics, setGenerics] = useState(genericsData);
  const [suggestions, setSuggestions] = useState(suggestedMedicines);
  const [searchTerm, setSearchTerm] = useState("");
  const [newGeneric, setNewGeneric] = useState({
    name: "",
    category: "",
    strength: "",
    brand: ""
  });
  const [showAddForm, setShowAddForm] = useState(false);
  const { toast } = useToast();

  const filteredGenerics = generics.filter(generic => 
    generic.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    generic.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const pendingSuggestions = suggestions.filter(s => s.status === 'pending');

  const handleAddGeneric = (e) => {
    e.preventDefault();
    if (!newGeneric.name || !newGeneric.category) {
      toast({
        title: "Error",
        description: "Please fill in required fields",
        variant: "destructive"
      });
      return;
    }

    const generic = {
      id: `GEN${String(generics.length + 1).padStart(3, '0')}`,
      name: newGeneric.name,
      category: newGeneric.category,
      strengths: newGeneric.strength ? [newGeneric.strength] : [],
      brands: newGeneric.brand ? [newGeneric.brand] : [],
      status: "active"
    };

    setGenerics([...generics, generic]);
    setNewGeneric({ name: "", category: "", strength: "", brand: "" });
    setShowAddForm(false);
    toast({
      title: "Success",
      description: "New generic medicine added successfully"
    });
  };

  const handleApproveSuggestion = (id) => {
    setSuggestions(prev => prev.map(s => 
      s.id === id ? { ...s, status: 'approved' } : s
    ));
    toast({
      title: "Suggestion Approved",
      description: "The medicine suggestion has been approved"
    });
  };

  const handleRejectSuggestion = (id) => {
    setSuggestions(prev => prev.map(s => 
      s.id === id ? { ...s, status: 'rejected' } : s
    ));
    toast({
      title: "Suggestion Rejected", 
      description: "The medicine suggestion has been rejected",
      variant: "destructive"
    });
  };

  const handleDeleteGeneric = (id) => {
    setGenerics(prev => prev.filter(g => g.id !== id));
    toast({
      title: "Medicine Deleted",
      description: "The generic medicine has been removed"
    });
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AdminSidebar />
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Medicine Master Management</h1>
            <p className="text-muted-foreground">Manage generic medicines, brands and user suggestions</p>
          </div>
          <Button onClick={() => setShowAddForm(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add New Generic
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">{generics.length}</p>
                <p className="text-sm text-muted-foreground">Total Generics</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-accent">
                  {generics.reduce((acc, g) => acc + g.brands.length, 0)}
                </p>
                <p className="text-sm text-muted-foreground">Total Brands</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-medicine-low">{pendingSuggestions.length}</p>
                <p className="text-sm text-muted-foreground">Pending Suggestions</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-medicine-available">
                  {suggestions.filter(s => s.status === 'approved').length}
                </p>
                <p className="text-sm text-muted-foreground">Approved Today</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="generics" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="generics">Generic Medicines</TabsTrigger>
            <TabsTrigger value="suggestions">
              User Suggestions 
              {pendingSuggestions.length > 0 && (
                <Badge variant="secondary" className="ml-2">{pendingSuggestions.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="add">Add New</TabsTrigger>
          </TabsList>

          <TabsContent value="generics" className="space-y-4">
            {/* Search */}
            <Card>
              <CardContent className="p-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search generic medicines or categories..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Generics List */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Pill className="h-5 w-5 text-primary" />
                  <span>Generic Medicines ({filteredGenerics.length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {filteredGenerics.map((generic) => (
                  <div key={generic.id} className="border border-border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-foreground">{generic.name}</h4>
                        <p className="text-sm text-muted-foreground">Category: {generic.category}</p>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleDeleteGeneric(generic.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium">Available Strengths:</Label>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {generic.strengths.map((strength, index) => (
                            <Badge key={index} variant="outline">{strength}</Badge>
                          ))}
                          {generic.strengths.length === 0 && (
                            <span className="text-sm text-muted-foreground">No strengths added</span>
                          )}
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Available Brands:</Label>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {generic.brands.map((brand, index) => (
                            <Badge key={index} variant="outline">{brand}</Badge>
                          ))}
                          {generic.brands.length === 0 && (
                            <span className="text-sm text-muted-foreground">No brands added</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="suggestions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertCircle className="h-5 w-5 text-primary" />
                  <span>User Suggestions ({suggestions.length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {suggestions.map((suggestion) => (
                  <div key={suggestion.id} className="border border-border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-foreground">{suggestion.genericName}</h4>
                        <p className="text-sm text-muted-foreground">Brand: {suggestion.brandName} | Strength: {suggestion.strength}</p>
                        <p className="text-sm text-muted-foreground">Category: {suggestion.category}</p>
                      </div>
                      <Badge className={
                        suggestion.status === 'pending' ? 'bg-medicine-low text-black' :
                        suggestion.status === 'approved' ? 'bg-medicine-available text-white' :
                        'bg-medicine-out text-white'
                      }>
                        {suggestion.status.charAt(0).toUpperCase() + suggestion.status.slice(1)}
                      </Badge>
                    </div>
                    
                    <div className="text-sm text-muted-foreground">
                      <p>Suggested by: {suggestion.suggestedBy}</p>
                      <p>Date: {suggestion.suggestedAt}</p>
                    </div>
                    
                    {suggestion.status === 'pending' && (
                      <div className="flex space-x-2">
                        <Button 
                          size="sm"
                          onClick={() => handleApproveSuggestion(suggestion.id)}
                          className="bg-medicine-available hover:bg-medicine-available/90"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleRejectSuggestion(suggestion.id)}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
                
                {suggestions.length === 0 && (
                  <div className="text-center py-8">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No medicine suggestions yet.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="add" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Add New Generic Medicine</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddGeneric} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Generic Name *</Label>
                      <Input
                        id="name"
                        value={newGeneric.name}
                        onChange={(e) => setNewGeneric({...newGeneric, name: e.target.value})}
                        placeholder="e.g., Paracetamol"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category">Category *</Label>
                      <Input
                        id="category"
                        value={newGeneric.category}
                        onChange={(e) => setNewGeneric({...newGeneric, category: e.target.value})}
                        placeholder="e.g., Analgesic"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="strength">Strength (Optional)</Label>
                      <Input
                        id="strength"
                        value={newGeneric.strength}
                        onChange={(e) => setNewGeneric({...newGeneric, strength: e.target.value})}
                        placeholder="e.g., 500mg"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="brand">Brand Name (Optional)</Label>
                      <Input
                        id="brand"
                        value={newGeneric.brand}
                        onChange={(e) => setNewGeneric({...newGeneric, brand: e.target.value})}
                        placeholder="e.g., Crocin"
                      />
                    </div>
                  </div>
                  <Button type="submit">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Generic Medicine
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}