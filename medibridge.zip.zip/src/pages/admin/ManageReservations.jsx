import { useState } from 'react';
import { SidebarProvider } from '@/components/ui/sidebar';
import { AdminSidebar } from '@/components/admin-sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Activity, 
  Search, 
  Calendar, 
  User, 
  Store, 
  Pill,
  Clock,
  Phone,
  Download,
  Filter
} from 'lucide-react';

const reservationsData = [
  {
    id: "RES001",
    customerName: "Rajesh Kumar",
    customerPhone: "+91 98765 43210",
    medicine: "Paracetamol 500mg",
    brand: "Crocin",
    pharmacy: "HealthCare Plus Pharmacy",
    pharmacyLocation: "MG Road, Bangalore",
    quantity: 2,
    reservedAt: "2024-01-15 10:30 AM",
    expiresAt: "2024-01-16 10:30 AM",
    status: "active",
    price: "₹40"
  },
  {
    id: "RES002", 
    customerName: "Priya Sharma",
    customerPhone: "+91 98765 43211",
    medicine: "Amoxicillin 250mg",
    brand: "Amoxil",
    pharmacy: "MediLife Pharmacy", 
    pharmacyLocation: "Jayanagar, Bangalore",
    quantity: 1,
    reservedAt: "2024-01-15 02:15 PM",
    expiresAt: "2024-01-16 02:15 PM",
    status: "collected",
    price: "₹120"
  },
  {
    id: "RES003",
    customerName: "Mohammed Ali",
    customerPhone: "+91 98765 43212", 
    medicine: "Omeprazole 20mg",
    brand: "Omez",
    pharmacy: "Apollo Pharmacy",
    pharmacyLocation: "Koramangala, Bangalore",
    quantity: 1,
    reservedAt: "2024-01-14 05:45 PM",
    expiresAt: "2024-01-15 05:45 PM",
    status: "expired",
    price: "₹85"
  },
  {
    id: "RES004",
    customerName: "Sunita Reddy",
    customerPhone: "+91 98765 43213",
    medicine: "Cetirizine 10mg", 
    brand: "Zyrtec",
    pharmacy: "HealthCare Plus Pharmacy",
    pharmacyLocation: "MG Road, Bangalore",
    quantity: 3,
    reservedAt: "2024-01-15 08:20 AM",
    expiresAt: "2024-01-16 08:20 AM",
    status: "cancelled",
    price: "₹90"
  },
  {
    id: "RES005",
    customerName: "Vikram Singh",
    customerPhone: "+91 98765 43214",
    medicine: "Ibuprofen 400mg",
    brand: "Brufen",
    pharmacy: "MediLife Pharmacy",
    pharmacyLocation: "Jayanagar, Bangalore", 
    quantity: 2,
    reservedAt: "2024-01-15 11:00 AM",
    expiresAt: "2024-01-16 11:00 AM",
    status: "active",
    price: "₹60"
  }
];

export default function ManageReservations() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [reservations] = useState(reservationsData);

  const filteredReservations = reservations.filter(reservation => {
    const matchesSearch = reservation.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         reservation.medicine.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         reservation.pharmacy.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         reservation.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || reservation.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    const statusConfig = {
      active: { className: 'bg-medicine-available text-white', label: 'Active' },
      collected: { className: 'bg-primary text-primary-foreground', label: 'Collected' },
      expired: { className: 'bg-medicine-out text-white', label: 'Expired' },
      cancelled: { className: 'bg-muted text-muted-foreground', label: 'Cancelled' }
    };
    
    const config = statusConfig[status] || statusConfig.active;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const getStatusCounts = () => {
    return {
      total: reservations.length,
      active: reservations.filter(r => r.status === 'active').length,
      collected: reservations.filter(r => r.status === 'collected').length,
      expired: reservations.filter(r => r.status === 'expired').length,
      cancelled: reservations.filter(r => r.status === 'cancelled').length
    };
  };

  const statusCounts = getStatusCounts();

  const exportData = () => {
    // Create CSV content
    const headers = ['ID', 'Customer', 'Phone', 'Medicine', 'Brand', 'Pharmacy', 'Quantity', 'Reserved At', 'Status', 'Price'];
    const csvContent = [
      headers.join(','),
      ...filteredReservations.map(r => [
        r.id,
        r.customerName,
        r.customerPhone,
        r.medicine,
        r.brand,
        r.pharmacy,
        r.quantity,
        r.reservedAt,
        r.status,
        r.price
      ].join(','))
    ].join('\n');

    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'reservations.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AdminSidebar />
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Manage Reservations</h1>
            <p className="text-muted-foreground">View and track all medicine reservations</p>
          </div>
          <Button onClick={exportData}>
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">{statusCounts.total}</p>
                <p className="text-sm text-muted-foreground">Total</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-medicine-available">{statusCounts.active}</p>
                <p className="text-sm text-muted-foreground">Active</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-accent">{statusCounts.collected}</p>
                <p className="text-sm text-muted-foreground">Collected</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-medicine-out">{statusCounts.expired}</p>
                <p className="text-sm text-muted-foreground">Expired</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-muted-foreground">{statusCounts.cancelled}</p>
                <p className="text-sm text-muted-foreground">Cancelled</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by customer, medicine, pharmacy, or reservation ID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Tabs value={statusFilter} onValueChange={setStatusFilter} className="w-auto">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="active">Active</TabsTrigger>
                  <TabsTrigger value="collected">Collected</TabsTrigger>
                  <TabsTrigger value="expired">Expired</TabsTrigger>
                  <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Reservations List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-primary" />
              <span>All Reservations ({filteredReservations.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {filteredReservations.map((reservation) => (
              <div key={reservation.id} className="border border-border rounded-lg p-4 space-y-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <h4 className="font-semibold text-foreground">#{reservation.id}</h4>
                      {getStatusBadge(reservation.status)}
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <span className="flex items-center space-x-1">
                        <User className="h-3 w-3" />
                        <span>{reservation.customerName}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Phone className="h-3 w-3" />
                        <span>{reservation.customerPhone}</span>
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-foreground">{reservation.price}</p>
                    <p className="text-sm text-muted-foreground">Qty: {reservation.quantity}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Pill className="h-4 w-4 text-primary" />
                      <div>
                        <p className="font-medium text-foreground">{reservation.medicine}</p>
                        <p className="text-sm text-muted-foreground">Brand: {reservation.brand}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Store className="h-4 w-4 text-primary" />
                      <div>
                        <p className="font-medium text-foreground">{reservation.pharmacy}</p>
                        <p className="text-sm text-muted-foreground">{reservation.pharmacyLocation}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-primary" />
                      <div>
                        <p className="text-sm text-foreground">Reserved: {reservation.reservedAt}</p>
                        <p className="text-sm text-muted-foreground">Expires: {reservation.expiresAt}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {filteredReservations.length === 0 && (
              <div className="text-center py-8">
                <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No reservations found matching your criteria.</p>
              </div>
            )}
          </CardContent>
        </Card>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}