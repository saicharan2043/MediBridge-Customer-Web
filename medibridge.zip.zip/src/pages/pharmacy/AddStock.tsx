import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Header } from '@/components/Header';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Package, Calendar, Hash } from 'lucide-react';

export default function AddStock() {
  const [stockData, setStockData] = useState({
    generic: '',
    strength: '',
    brand: '',
    quantity: '',
    expiryDate: '',
    batchNumber: '',
    costPrice: '',
    sellingPrice: ''
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  const generics = [
    'Paracetamol',
    'Aspirin',
    'Ibuprofen',
    'Amoxicillin',
    'Omeprazole',
    'Metformin',
    'Atorvastatin',
    'Vitamin D3'
  ];

  const strengths = {
    'Paracetamol': ['500mg', '650mg', '1000mg'],
    'Aspirin': ['75mg', '325mg', '500mg'],
    'Ibuprofen': ['200mg', '400mg', '600mg'],
    'Amoxicillin': ['250mg', '500mg', '875mg'],
    'Omeprazole': ['20mg', '40mg'],
    'Metformin': ['500mg', '850mg', '1000mg'],
    'Atorvastatin': ['10mg', '20mg', '40mg', '80mg'],
    'Vitamin D3': ['1000IU', '2000IU', '5000IU']
  };

  const brands = {
    'Paracetamol': ['Crocin', 'Dolo', 'Calpol', 'Panadol'],
    'Aspirin': ['Disprin', 'Ecosprin', 'Loprin'],
    'Ibuprofen': ['Brufen', 'Combiflam', 'Ibugesic'],
    'Amoxicillin': ['Novamox', 'Amoxil', 'Augmentin'],
    'Omeprazole': ['Omez', 'Prilosec', 'Losec'],
    'Metformin': ['Glycomet', 'Glucophage', 'Metsmall'],
    'Atorvastatin': ['Atorlip', 'Lipitor', 'Storvas'],
    'Vitamin D3': ['Calcirol', 'Uprise', 'Shelcal']
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!stockData.generic || !stockData.strength || !stockData.brand || !stockData.quantity || !stockData.expiryDate) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Simulate saving stock
    toast({
      title: "Stock Added Successfully",
      description: `${stockData.quantity} units of ${stockData.brand} ${stockData.strength} added to inventory`,
    });

    // Reset form
    setStockData({
      generic: '',
      strength: '',
      brand: '',
      quantity: '',
      expiryDate: '',
      batchNumber: '',
      costPrice: '',
      sellingPrice: ''
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center space-x-4 mb-8">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/pharmacy/dashboard')}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Dashboard</span>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Add Stock</h1>
              <p className="text-muted-foreground">Add new medicine stock to your inventory</p>
            </div>
          </div>

          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-foreground">
                <Package className="h-5 w-5" />
                <span>Stock Information</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Medicine Selection */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="generic">Generic Name *</Label>
                    <Select 
                      value={stockData.generic} 
                      onValueChange={(value) => setStockData({...stockData, generic: value, strength: '', brand: ''})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select generic" />
                      </SelectTrigger>
                      <SelectContent>
                        {generics.map((generic) => (
                          <SelectItem key={generic} value={generic}>{generic}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="strength">Strength *</Label>
                    <Select 
                      value={stockData.strength} 
                      onValueChange={(value) => setStockData({...stockData, strength: value, brand: ''})}
                      disabled={!stockData.generic}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select strength" />
                      </SelectTrigger>
                      <SelectContent>
                        {stockData.generic && strengths[stockData.generic as keyof typeof strengths]?.map((strength) => (
                          <SelectItem key={strength} value={strength}>{strength}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="brand">Brand *</Label>
                    <Select 
                      value={stockData.brand} 
                      onValueChange={(value) => setStockData({...stockData, brand: value})}
                      disabled={!stockData.generic}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select brand" />
                      </SelectTrigger>
                      <SelectContent>
                        {stockData.generic && brands[stockData.generic as keyof typeof brands]?.map((brand) => (
                          <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Stock Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity *</Label>
                    <div className="relative">
                      <Hash className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="quantity"
                        type="number"
                        placeholder="100"
                        value={stockData.quantity}
                        onChange={(e) => setStockData({...stockData, quantity: e.target.value})}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="expiryDate">Expiry Date *</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="expiryDate"
                        type="date"
                        value={stockData.expiryDate}
                        onChange={(e) => setStockData({...stockData, expiryDate: e.target.value})}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Additional Information */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="batchNumber">Batch Number</Label>
                    <Input
                      id="batchNumber"
                      placeholder="BT123456"
                      value={stockData.batchNumber}
                      onChange={(e) => setStockData({...stockData, batchNumber: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="costPrice">Cost Price (₹)</Label>
                    <Input
                      id="costPrice"
                      type="number"
                      step="0.01"
                      placeholder="10.00"
                      value={stockData.costPrice}
                      onChange={(e) => setStockData({...stockData, costPrice: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sellingPrice">Selling Price (₹)</Label>
                    <Input
                      id="sellingPrice"
                      type="number"
                      step="0.01"
                      placeholder="15.00"
                      value={stockData.sellingPrice}
                      onChange={(e) => setStockData({...stockData, sellingPrice: e.target.value})}
                    />
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-4 pt-6">
                  <Button 
                    type="submit" 
                    className="flex-1 gradient-primary text-primary-foreground"
                  >
                    Add to Inventory
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => navigate('/pharmacy/dashboard')}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}