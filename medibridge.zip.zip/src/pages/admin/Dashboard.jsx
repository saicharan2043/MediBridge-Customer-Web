import { SidebarProvider } from '@/components/ui/sidebar';
import { AdminSidebar } from '@/components/admin-sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Shield, 
  Store, 
  Users, 
  Activity, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  Eye,
  Download,
  Calendar,
  Clock
} from 'lucide-react';

const overviewStats = [
  {
    title: "Total Pharmacies",
    value: "156",
    change: "+8",
    description: "Active registered pharmacies",
    icon: Store,
    color: "primary"
  },
  {
    title: "Total Users",
    value: "12,458",
    change: "+234",
    description: "Registered customers",
    icon: Users,
    color: "medicine-available"
  },
  {
    title: "Daily Reservations",
    value: "1,247",
    change: "+89", 
    description: "Today's total reservations",
    icon: Activity,
    color: "accent"
  },
  {
    title: "Pending Approvals",
    value: "23",
    change: "+5",
    description: "Pharmacy applications pending",
    icon: AlertTriangle,
    color: "medicine-low"
  }
];

const pendingPharmacies = [
  {
    id: "PHR001",
    name: "HealthCare Plus Pharmacy",
    ownerName: "Dr. Ramesh Gupta",
    location: "MG Road, Bangalore",
    phone: "+91 98765 43210",
    appliedDate: "2 days ago",
    licenseNumber: "KA/BLR/2024/001",
    status: "pending"
  },
  {
    id: "PHR002", 
    name: "MediLife Pharmacy",
    ownerName: "Sunita Sharma",
    location: "Jayanagar, Bangalore",
    phone: "+91 98765 43211",
    appliedDate: "3 days ago",
    licenseNumber: "KA/BLR/2024/002",
    status: "pending"
  },
  {
    id: "PHR003",
    name: "Quick Heal Pharmacy",
    ownerName: "Mohammed Asif",
    location: "Electronic City, Bangalore",
    phone: "+91 98765 43212",
    appliedDate: "1 week ago",
    licenseNumber: "KA/BLR/2024/003",
    status: "under_review"
  }
];

const recentActivities = [
  {
    type: "pharmacy_approved",
    message: "Apollo Pharmacy - Koramangala approved",
    time: "2 hours ago",
    icon: CheckCircle,
    color: "medicine-available"
  },
  {
    type: "pharmacy_rejected",
    message: "MediQuick Store application rejected",
    time: "4 hours ago", 
    icon: XCircle,
    color: "medicine-out"
  },
  {
    type: "high_reservations",
    message: "Peak reservation activity detected",
    time: "6 hours ago",
    icon: TrendingUp,
    color: "primary"
  },
  {
    type: "new_application",
    message: "New pharmacy application received",
    time: "8 hours ago",
    icon: Store,
    color: "accent"
  }
];

const topMedicines = [
  { name: "Paracetamol 500mg", reservations: 456, trend: "+12%" },
  { name: "Amoxicillin 250mg", reservations: 234, trend: "+8%" },
  { name: "Omeprazole 20mg", reservations: 198, trend: "+15%" },
  { name: "Cetirizine 10mg", reservations: 176, trend: "+5%" },
  { name: "Ibuprofen 400mg", reservations: 145, trend: "+3%" }
];

export default function AdminDashboard() {
  const handleApprovePharmacy = (id) => {
    console.log("Approve pharmacy:", id);
  };

  const handleRejectPharmacy = (id) => {
    console.log("Reject pharmacy:", id);
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AdminSidebar />
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto px-4 py-6 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
                <p className="text-muted-foreground">Monitor and manage the MediBridge platform</p>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export Data
                </Button>
                <Button>
                  <Eye className="h-4 w-4 mr-2" />
                  View Reports
                </Button>
              </div>
            </div>

            {/* Overview Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {overviewStats.map((stat) => {
                const Icon = stat.icon;
                return (
                  <Card key={stat.title} className="bg-gradient-to-br from-card to-muted/20">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">{stat.title}</p>
                          <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                          <p className="text-sm text-medicine-available">
                            +{stat.change} this week
                          </p>
                        </div>
                        <div className="p-3 bg-primary/10 rounded-full">
                          <Icon className="h-6 w-6 text-primary" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-6">
                <Tabs defaultValue="pharmacies" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="pharmacies">Pending Pharmacies</TabsTrigger>
                    <TabsTrigger value="analytics">Analytics</TabsTrigger>
                    <TabsTrigger value="medicines">Top Medicines</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="pharmacies" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <Store className="h-5 w-5 text-primary" />
                          <span>Pharmacy Applications</span>
                          <Badge variant="secondary">{pendingPharmacies.length} pending</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {pendingPharmacies.map((pharmacy) => (
                          <div key={pharmacy.id} className="border border-border rounded-lg p-4 space-y-3">
                            <div className="flex items-start justify-between">
                              <div>
                                <h4 className="font-medium text-foreground">{pharmacy.name}</h4>
                                <p className="text-sm text-muted-foreground">Owner: {pharmacy.ownerName}</p>
                                <p className="text-sm text-muted-foreground">{pharmacy.location}</p>
                              </div>
                              <Badge className={
                                pharmacy.status === 'pending' ? 'bg-medicine-low text-black' : 'bg-accent text-accent-foreground'
                              }>
                                {pharmacy.status === 'pending' ? 'Pending' : 'Under Review'}
                              </Badge>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-muted-foreground">Phone: </span>
                                <span className="text-foreground">{pharmacy.phone}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Applied: </span>
                                <span className="text-foreground">{pharmacy.appliedDate}</span>
                              </div>
                            </div>
                            
                            <div className="text-sm">
                              <span className="text-muted-foreground">License: </span>
                              <span className="text-foreground font-mono">{pharmacy.licenseNumber}</span>
                            </div>
                            
                            <div className="flex space-x-2">
                              <Button 
                                size="sm" 
                                onClick={() => handleApprovePharmacy(pharmacy.id)}
                                className="bg-medicine-available hover:bg-medicine-available/90"
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Approve
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => handleRejectPharmacy(pharmacy.id)}
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                Reject
                              </Button>
                              <Button size="sm" variant="ghost">
                                <Eye className="h-4 w-4 mr-1" />
                                Review
                              </Button>
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="analytics" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Daily Reservations</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold text-primary mb-2">1,247</div>
                          <p className="text-sm text-medicine-available">+12% from yesterday</p>
                          <div className="mt-4 h-20 bg-gradient-to-r from-primary/20 to-primary/5 rounded flex items-end">
                            <div className="text-xs text-muted-foreground p-2">Chart visualization would go here</div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Active Pharmacies</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold text-medicine-available mb-2">156</div>
                          <p className="text-sm text-primary">8 new this week</p>
                          <div className="mt-4 h-20 bg-gradient-to-r from-medicine-available/20 to-medicine-available/5 rounded flex items-end">
                            <div className="text-xs text-muted-foreground p-2">Chart visualization would go here</div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  <TabsContent value="medicines" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <TrendingUp className="h-5 w-5 text-primary" />
                          <span>Most Reserved Medicines</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {topMedicines.map((medicine, index) => (
                            <div key={medicine.name} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                              <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                                  <span className="text-sm font-medium text-primary">#{index + 1}</span>
                                </div>
                                <div>
                                  <h4 className="font-medium text-foreground">{medicine.name}</h4>
                                  <p className="text-sm text-muted-foreground">{medicine.reservations} reservations</p>
                                </div>
                              </div>
                              <Badge variant="outline" className="text-medicine-available">
                                {medicine.trend}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Recent Activities */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Activity className="h-5 w-5 text-primary" />
                      <span>Recent Activities</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {recentActivities.map((activity, index) => {
                      const Icon = activity.icon;
                      return (
                        <div key={index} className="flex items-start space-x-3 p-2 rounded-lg hover:bg-muted/20">
                          <div className="p-1 rounded-full bg-primary/10">
                            <Icon className="h-4 w-4 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-foreground">{activity.message}</p>
                            <p className="text-xs text-muted-foreground flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              {activity.time}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </CardContent>
                </Card>

                {/* System Status */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-primary" />
                      <span>System Status</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-foreground">API Status</span>
                      <Badge className="bg-medicine-available text-white">Operational</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-foreground">Database</span>
                      <Badge className="bg-medicine-available text-white">Healthy</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-foreground">SMS Service</span>
                      <Badge className="bg-medicine-available text-white">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-foreground">Server Load</span>
                      <Badge variant="outline">67%</Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" className="w-full justify-start">
                      <Users className="h-4 w-4 mr-2" />
                      Manage Users
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Store className="h-4 w-4 mr-2" />
                      Add New Medicine
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Calendar className="h-4 w-4 mr-2" />
                      Schedule Maintenance
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}