
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  User, 
  Calendar, 
  Clock, 
  MapPin, 
  Pill,
  Heart,
  Bell,
  Store,
  Phone,
  Edit,
  Trash2,
  RefreshCw
} from 'lucide-react';

const sampleUser = {
  name: "John Doe",
  email: "john.doe@example.com",
  phone: "+91 98765 43213",
  location: "Bangalore, Karnataka"
};

const sampleReservations = [
  {
    id: "RES123456",
    medicine: {
      brand: "Crocin",
      generic: "Paracetamol",
      strength: "500mg",
      price: 15
    },
    pharmacy: {
      name: "Apollo Pharmacy",
      address: "MG Road, Bangalore",
      phone: "+91 98765 43210"
    },
    status: "active",
    reservedAt: new Date(Date.now() - 30 * 60 * 1000),
    expiresAt: new Date(Date.now() + 90 * 60 * 1000)
  },
  {
    id: "RES123455",
    medicine: {
      brand: "Dolo 650",
      generic: "Paracetamol", 
      strength: "650mg",
      price: 18
    },
    pharmacy: {
      name: "MedPlus",
      address: "Brigade Road, Bangalore",
      phone: "+91 98765 43211"  
    },
    status: "completed",
    reservedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    expiresAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 + 2 * 60 * 60 * 1000)
  },
  {
    id: "RES123454",
    medicine: {
      brand: "Panadol",
      generic: "Paracetamol",
      strength: "500mg", 
      price: 12
    },
    pharmacy: {
      name: "Wellness Pharmacy",
      address: "Commercial Street, Bangalore",
      phone: "+91 98765 43212"
    },
    status: "expired",
    reservedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    expiresAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000 + 2 * 60 * 60 * 1000)
  }
];

const sampleReminders = [
  {
    id: 1,
    medicine: "Crocin 500mg",
    frequency: "Twice daily",
    nextDue: new Date(Date.now() + 4 * 60 * 60 * 1000),
    isActive: true
  },
  {
    id: 2,
    medicine: "Vitamin D3",
    frequency: "Once weekly",
    nextDue: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    isActive: true
  }
];

const sampleFavorites = [
  {
    id: 1,
    pharmacy: {
      name: "Apollo Pharmacy",
      address: "MG Road, Bangalore",
      distance: "0.5 km",
      phone: "+91 98765 43210"
    },
    visitCount: 12
  },
  {
    id: 2,
    pharmacy: {
      name: "MedPlus",
      address: "Brigade Road, Bangalore", 
      distance: "1.2 km",
      phone: "+91 98765 43211"
    },
    visitCount: 8
  }
];

export default function CustomerDashboard() {
  const [activeTab, setActiveTab] = useState("reservations");

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-medicine-available text-white';
      case 'completed': return 'bg-primary text-primary-foreground';
      case 'expired': return 'bg-medicine-out text-white';
      default: return 'bg-muted';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Active';
      case 'completed': return 'Completed';
      case 'expired': return 'Expired';
      default: return 'Unknown';
    }
  };

  const formatDateTime = (date: Date) => {
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Welcome back, {sampleUser.name}!
          </h1>
          <p className="text-muted-foreground">
            Manage your medicine reservations and track your health needs
          </p>
        </div>

        {/* Demo Credentials Notice */}
        <Card className="mb-6 bg-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <User className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <h3 className="font-semibold text-foreground mb-1">Demo Credentials</h3>
                <p className="text-sm text-muted-foreground">
                  <strong>Email:</strong> {sampleUser.email} | <strong>Phone:</strong> {sampleUser.phone}
                  <br />
                  This is a demo dashboard showing how the customer portal would look with real data.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="gradient-card border-border">
            <CardContent className="p-6 text-center">
              <Calendar className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">
                {sampleReservations.length}
              </div>
              <p className="text-sm text-muted-foreground">Total Reservations</p>
            </CardContent>
          </Card>
          
          <Card className="gradient-card border-border">
            <CardContent className="p-6 text-center">
              <Clock className="h-8 w-8 text-medicine-available mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">
                {sampleReservations.filter(r => r.status === 'active').length}
              </div>
              <p className="text-sm text-muted-foreground">Active Reservations</p>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardContent className="p-6 text-center">
              <Bell className="h-8 w-8 text-medicine-low mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">
                {sampleReminders.filter(r => r.isActive).length}
              </div>
              <p className="text-sm text-muted-foreground">Active Reminders</p>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardContent className="p-6 text-center">
              <Heart className="h-8 w-8 text-destructive mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">
                {sampleFavorites.length}
              </div>
              <p className="text-sm text-muted-foreground">Favorite Pharmacies</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="reservations">Reservations</TabsTrigger>
            <TabsTrigger value="reminders">Reminders</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          {/* Reservations Tab */}
          <TabsContent value="reservations" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold text-foreground">Your Reservations</h2>
              <Button asChild className="gradient-primary text-primary-foreground">
                <Link to="/">
                  <Pill className="h-4 w-4 mr-2" />
                  New Reservation
                </Link>
              </Button>
            </div>

            {sampleReservations.map((reservation) => (
              <Card key={reservation.id} className="gradient-card border-border">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="text-lg font-semibold text-foreground">
                            {reservation.medicine.brand} {reservation.medicine.strength}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            Generic: {reservation.medicine.generic}
                          </p>
                        </div>
                        <Badge className={getStatusColor(reservation.status)}>
                          {getStatusText(reservation.status)}
                        </Badge>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center text-sm">
                          <Store className="h-4 w-4 text-primary mr-2" />
                          <span className="text-muted-foreground">
                            {reservation.pharmacy.name} - {reservation.pharmacy.address}
                          </span>
                        </div>
                        
                        <div className="flex items-center text-sm">
                          <Calendar className="h-4 w-4 text-primary mr-2" />
                          <span className="text-muted-foreground">
                            Reserved: {formatDateTime(reservation.reservedAt)}
                          </span>
                        </div>

                        {reservation.status === 'active' && (
                          <div className="flex items-center text-sm">
                            <Clock className="h-4 w-4 text-destructive mr-2" />
                            <span className="text-destructive font-medium">
                              Expires: {formatDateTime(reservation.expiresAt)}
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                        <span className="text-lg font-semibold text-primary">
                          ₹{reservation.medicine.price}
                        </span>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Phone className="h-4 w-4 mr-2" />
                            Call Pharmacy
                          </Button>
                          {reservation.status === 'active' && (
                            <Button variant="outline" size="sm">
                              <MapPin className="h-4 w-4 mr-2" />
                              Directions
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Reminders Tab */}
          <TabsContent value="reminders" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold text-foreground">Refill Reminders</h2>
              <Button className="gradient-primary text-primary-foreground">
                <Bell className="h-4 w-4 mr-2" />
                Add Reminder
              </Button>
            </div>

            {sampleReminders.map((reminder) => (
              <Card key={reminder.id} className="gradient-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-foreground">
                        {reminder.medicine}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {reminder.frequency}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Next due: {formatDateTime(reminder.nextDue)}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button variant="outline" size="sm">
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Refill Now
                      </Button>
                      <Button variant="outline" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Favorites Tab */}
          <TabsContent value="favorites" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold text-foreground">Favorite Pharmacies</h2>
              <Button asChild className="gradient-primary text-primary-foreground">
                <Link to="/">
                  <Store className="h-4 w-4 mr-2" />
                  Find More
                </Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {sampleFavorites.map((favorite) => (
                <Card key={favorite.id} className="gradient-card border-border">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold text-foreground">
                          {favorite.pharmacy.name}
                        </h3>
                        <Heart className="h-5 w-5 text-destructive" />
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center text-sm">
                          <MapPin className="h-4 w-4 text-primary mr-2" />
                          <span className="text-muted-foreground">
                            {favorite.pharmacy.address}
                          </span>
                        </div>
                        <div className="flex items-center text-sm">
                          <Phone className="h-4 w-4 text-primary mr-2" />
                          <span className="text-muted-foreground">
                            {favorite.pharmacy.phone}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-border">
                        <span className="text-sm text-muted-foreground">
                          {favorite.visitCount} visits
                        </span>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Phone className="h-4 w-4 mr-2" />
                            Call
                          </Button>
                          <Button variant="outline" size="sm">
                            <MapPin className="h-4 w-4 mr-2" />
                            Directions
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <h2 className="text-2xl font-semibold text-foreground">Profile Settings</h2>
            
            <Card className="gradient-card border-border">
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      defaultValue={sampleUser.name}
                      className="bg-background border-border"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      defaultValue={sampleUser.email}
                      className="bg-background border-border"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      type="tel"
                      defaultValue={sampleUser.phone}
                      className="bg-background border-border"
                    />
                  </div>
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      defaultValue={sampleUser.location}
                      className="bg-background border-border"
                    />
                  </div>
                </div>
                <Button className="gradient-primary text-primary-foreground">
                  Update Profile
                </Button>
              </CardContent>
            </Card>

            <Card className="gradient-card border-border">
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-foreground">Reservation reminders</span>
                    <Button variant="outline" size="sm">On</Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-foreground">Medicine expiry alerts</span>
                    <Button variant="outline" size="sm">On</Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-foreground">New pharmacy notifications</span>
                    <Button variant="outline" size="sm">Off</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
