import { useState } from 'react';
import { SidebarProvider } from '@/components/ui/sidebar';
import { AdminSidebar } from '@/components/admin-sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Store, 
  Search, 
  CheckCircle, 
  XCircle, 
  Eye, 
  MapPin, 
  Phone,
  Calendar,
  FileText,
  Filter
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const pharmaciesData = [
  {
    id: "PHR001",
    name: "HealthCare Plus Pharmacy",
    ownerName: "Dr. Ramesh Gupta",
    location: "MG Road, Bangalore",
    phone: "+91 98765 43210",
    email: "ramesh@healthcare.com",
    licenseNumber: "KA/BLR/2024/001",
    status: "pending",
    appliedDate: "2024-01-15",
    documents: ["license.pdf", "kyc.pdf"]
  },
  {
    id: "PHR002",
    name: "MediLife Pharmacy",
    ownerName: "Sunita Sharma",
    location: "Jayanagar, Bangalore",
    phone: "+91 98765 43211", 
    email: "sunita@medilife.com",
    licenseNumber: "KA/BLR/2024/002",
    status: "approved",
    appliedDate: "2024-01-10",
    documents: ["license.pdf", "kyc.pdf"]
  },
  {
    id: "PHR003",
    name: "Apollo Pharmacy",
    ownerName: "Dr. Krishna Kumar",
    location: "Koramangala, Bangalore",
    phone: "+91 98765 43212",
    email: "krishna@apollo.com",
    licenseNumber: "KA/BLR/2024/003",
    status: "approved",
    appliedDate: "2024-01-12",
    documents: ["license.pdf", "kyc.pdf", "store_photos.pdf"]
  },
  {
    id: "PHR004",
    name: "Quick Heal Pharmacy",
    ownerName: "Mohammed Asif",
    location: "Electronic City, Bangalore",
    phone: "+91 98765 43213",
    email: "asif@quickheal.com",
    licenseNumber: "KA/BLR/2024/004",
    status: "rejected",
    appliedDate: "2024-01-08",
    documents: ["license.pdf"]
  }
];

export default function ManagePharmacies() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [pharmacies, setPharmacies] = useState(pharmaciesData);
  const { toast } = useToast();

  const filteredPharmacies = pharmacies.filter(pharmacy => {
    const matchesSearch = pharmacy.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pharmacy.ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pharmacy.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || pharmacy.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleApprove = (id) => {
    setPharmacies(prev => prev.map(p => 
      p.id === id ? { ...p, status: 'approved' } : p
    ));
    toast({
      title: "Pharmacy Approved",
      description: "The pharmacy has been successfully approved."
    });
  };

  const handleReject = (id) => {
    setPharmacies(prev => prev.map(p => 
      p.id === id ? { ...p, status: 'rejected' } : p
    ));
    toast({
      title: "Pharmacy Rejected",
      description: "The pharmacy application has been rejected.",
      variant: "destructive"
    });
  };

  const handleDeactivate = (id) => {
    setPharmacies(prev => prev.map(p => 
      p.id === id ? { ...p, status: 'deactivated' } : p
    ));
    toast({
      title: "Pharmacy Deactivated",
      description: "The pharmacy has been deactivated.",
      variant: "destructive"
    });
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      pending: { className: 'bg-medicine-low text-black', label: 'Pending' },
      approved: { className: 'bg-medicine-available text-white', label: 'Approved' },
      rejected: { className: 'bg-medicine-out text-white', label: 'Rejected' },
      deactivated: { className: 'bg-muted text-muted-foreground', label: 'Deactivated' }
    };
    
    const config = statusConfig[status] || statusConfig.pending;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const getStatusCounts = () => {
    return {
      total: pharmacies.length,
      pending: pharmacies.filter(p => p.status === 'pending').length,
      approved: pharmacies.filter(p => p.status === 'approved').length,
      rejected: pharmacies.filter(p => p.status === 'rejected').length
    };
  };

  const statusCounts = getStatusCounts();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AdminSidebar />
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Manage Pharmacies</h1>
            <p className="text-muted-foreground">Review and manage pharmacy applications</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">{statusCounts.total}</p>
                <p className="text-sm text-muted-foreground">Total Pharmacies</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-medicine-low">{statusCounts.pending}</p>
                <p className="text-sm text-muted-foreground">Pending Approval</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-medicine-available">{statusCounts.approved}</p>
                <p className="text-sm text-muted-foreground">Approved</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-medicine-out">{statusCounts.rejected}</p>
                <p className="text-sm text-muted-foreground">Rejected</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by pharmacy name, owner, or location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Tabs value={statusFilter} onValueChange={setStatusFilter} className="w-auto">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="pending">Pending</TabsTrigger>
                  <TabsTrigger value="approved">Approved</TabsTrigger>
                  <TabsTrigger value="rejected">Rejected</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Pharmacies List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Store className="h-5 w-5 text-primary" />
              <span>Pharmacy Applications ({filteredPharmacies.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {filteredPharmacies.map((pharmacy) => (
              <div key={pharmacy.id} className="border border-border rounded-lg p-4 space-y-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <h4 className="font-semibold text-foreground">{pharmacy.name}</h4>
                    <p className="text-sm text-muted-foreground">Owner: {pharmacy.ownerName}</p>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <span className="flex items-center space-x-1">
                        <MapPin className="h-3 w-3" />
                        <span>{pharmacy.location}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Phone className="h-3 w-3" />
                        <span>{pharmacy.phone}</span>
                      </span>
                    </div>
                  </div>
                  {getStatusBadge(pharmacy.status)}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Email: </span>
                    <span className="text-foreground">{pharmacy.email}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">License: </span>
                    <span className="text-foreground font-mono">{pharmacy.licenseNumber}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Applied: </span>
                    <span className="text-foreground">{pharmacy.appliedDate}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      {pharmacy.documents.length} document(s) uploaded
                    </span>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4 mr-1" />
                      View Details
                    </Button>
                    
                    {pharmacy.status === 'pending' && (
                      <>
                        <Button 
                          size="sm"
                          onClick={() => handleApprove(pharmacy.id)}
                          className="bg-medicine-available hover:bg-medicine-available/90"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleReject(pharmacy.id)}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </>
                    )}
                    
                    {pharmacy.status === 'approved' && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleDeactivate(pharmacy.id)}
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Deactivate
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {filteredPharmacies.length === 0 && (
              <div className="text-center py-8">
                <Store className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No pharmacies found matching your criteria.</p>
              </div>
            )}
          </CardContent>
        </Card>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}