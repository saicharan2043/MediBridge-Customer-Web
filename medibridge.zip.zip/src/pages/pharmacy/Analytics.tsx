import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/Header';
import { ArrowLeft, TrendingUp, Download, Calendar, Clock, Package, Users } from 'lucide-react';

export default function Analytics() {
  const navigate = useNavigate();

  const topMedicines = [
    { name: 'Paracetamol', brand: 'Crocin', reservations: 45, trend: '+12%' },
    { name: 'Aspirin', brand: 'Disprin', reservations: 32, trend: '+8%' },
    { name: 'Ibuprofen', brand: 'Brufen', reservations: 28, trend: '+15%' },
    { name: 'Vitamin D3', brand: 'Calcirol', reservations: 21, trend: '-3%' },
    { name: 'Omeprazole', brand: 'Omez', reservations: 18, trend: '+5%' }
  ];

  const timeSlots = [
    { time: '9:00 AM - 12:00 PM', reservations: 35, percentage: 32 },
    { time: '12:00 PM - 3:00 PM', reservations: 28, percentage: 26 },
    { time: '3:00 PM - 6:00 PM', reservations: 31, percentage: 28 },
    { time: '6:00 PM - 9:00 PM', reservations: 15, percentage: 14 }
  ];

  const monthlyData = [
    { month: 'Jan', reservations: 234, revenue: 45600 },
    { month: 'Feb', reservations: 267, revenue: 52300 },
    { month: 'Mar', reservations: 298, revenue: 58900 },
    { month: 'Apr', reservations: 312, revenue: 61200 },
    { month: 'May', reservations: 345, revenue: 67800 },
    { month: 'Jun', reservations: 378, revenue: 74100 }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/pharmacy/dashboard')}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Dashboard</span>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Analytics Dashboard</h1>
              <p className="text-muted-foreground">Track your pharmacy performance and insights</p>
            </div>
          </div>
          
          <Button className="gradient-primary text-primary-foreground flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Download Report</span>
          </Button>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Reservations</CardTitle>
              <Calendar className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">1,834</div>
              <p className="text-xs text-medicine-available">+12.5% from last month</p>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Revenue</CardTitle>
              <TrendingUp className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">₹74,100</div>
              <p className="text-xs text-medicine-available">+9.2% from last month</p>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Customers</CardTitle>
              <Users className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">456</div>
              <p className="text-xs text-medicine-available">+8.1% from last month</p>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Stock Items</CardTitle>
              <Package className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">1,247</div>
              <p className="text-xs text-muted-foreground">8 items low stock</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Top Reserved Medicines */}
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground">Top Reserved Medicines</CardTitle>
              <p className="text-sm text-muted-foreground">Most popular medicines this month</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topMedicines.map((medicine, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-semibold text-primary">{index + 1}</span>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{medicine.brand}</p>
                        <p className="text-sm text-muted-foreground">{medicine.name}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-foreground">{medicine.reservations} reservations</p>
                      <Badge 
                        variant={medicine.trend.startsWith('+') ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {medicine.trend}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Popular Time Slots */}
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>Popular Time Slots</span>
              </CardTitle>
              <p className="text-sm text-muted-foreground">Peak reservation hours</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {timeSlots.map((slot, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-foreground">{slot.time}</span>
                      <span className="text-sm text-muted-foreground">{slot.reservations} reservations</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full transition-all duration-500"
                        style={{ width: `${slot.percentage}%` }}
                      ></div>
                    </div>
                    <div className="text-xs text-muted-foreground text-right">{slot.percentage}%</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Monthly Performance */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Monthly Performance</CardTitle>
            <p className="text-sm text-muted-foreground">Reservations and revenue trends over the last 6 months</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
              {monthlyData.map((data, index) => (
                <div key={index} className="text-center p-4 rounded-lg bg-muted/50">
                  <p className="text-sm font-medium text-muted-foreground mb-2">{data.month}</p>
                  <div className="space-y-1">
                    <p className="text-lg font-bold text-foreground">{data.reservations}</p>
                    <p className="text-xs text-muted-foreground">reservations</p>
                    <p className="text-sm font-semibold text-primary">₹{data.revenue.toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Download Reports Section */}
        <Card className="gradient-card border-border mt-8">
          <CardHeader>
            <CardTitle className="text-foreground">Download Reports</CardTitle>
            <p className="text-sm text-muted-foreground">Export detailed reports for your records</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="flex items-center space-x-2">
                <Download className="h-4 w-4" />
                <span>Stock Report</span>
              </Button>
              <Button variant="outline" className="flex items-center space-x-2">
                <Download className="h-4 w-4" />
                <span>Sales Report</span>
              </Button>
              <Button variant="outline" className="flex items-center space-x-2">
                <Download className="h-4 w-4" />
                <span>Customer Report</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}