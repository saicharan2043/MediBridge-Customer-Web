import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Header } from '@/components/Header';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Check, Clock, X, Phone, User } from 'lucide-react';

interface Reservation {
  id: string;
  customerName: string;
  customerPhone: string;
  medicine: string;
  brand: string;
  strength: string;
  quantity: number;
  reservedAt: string;
  expiresAt: string;
  status: 'pending' | 'accepted' | 'collected' | 'cancelled' | 'expired';
}

export default function ReservationRequests() {
  const [reservations, setReservations] = useState<Reservation[]>([
    {
      id: '1',
      customerName: 'John Doe',
      customerPhone: '+91 98765 43210',
      medicine: 'Paracetamol',
      brand: 'Crocin',
      strength: '500mg',
      quantity: 2,
      reservedAt: '2024-01-15T09:30:00Z',
      expiresAt: '2024-01-15T21:30:00Z',
      status: 'pending'
    },
    {
      id: '2',
      customerName: 'Jane Smith',
      customerPhone: '+91 98765 43211',
      medicine: 'Aspirin',
      brand: 'Disprin',
      strength: '325mg',
      quantity: 1,
      reservedAt: '2024-01-15T10:15:00Z',
      expiresAt: '2024-01-15T22:15:00Z',
      status: 'accepted'
    },
    {
      id: '3',
      customerName: 'Mike Johnson',
      customerPhone: '+91 98765 43212',
      medicine: 'Ibuprofen',
      brand: 'Brufen',
      strength: '400mg',
      quantity: 1,
      reservedAt: '2024-01-15T11:00:00Z',
      expiresAt: '2024-01-15T23:00:00Z',
      status: 'pending'
    },
    {
      id: '4',
      customerName: 'Sarah Wilson',
      customerPhone: '+91 98765 43213',
      medicine: 'Vitamin D3',
      brand: 'Calcirol',
      strength: '2000IU',
      quantity: 1,
      reservedAt: '2024-01-15T08:45:00Z',
      expiresAt: '2024-01-15T20:45:00Z',
      status: 'collected'
    },
    {
      id: '5',
      customerName: 'David Brown',
      customerPhone: '+91 98765 43214',
      medicine: 'Omeprazole',
      brand: 'Omez',
      strength: '20mg',
      quantity: 1,
      reservedAt: '2024-01-14T16:30:00Z',
      expiresAt: '2024-01-15T04:30:00Z',
      status: 'expired'
    }
  ]);

  const navigate = useNavigate();
  const { toast } = useToast();

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'pending': return 'secondary';
      case 'accepted': return 'default';
      case 'collected': return 'default';
      case 'cancelled': return 'destructive';
      case 'expired': return 'outline';
      default: return 'outline';
    }
  };

  const handleAccept = (reservationId: string) => {
    setReservations(prev => 
      prev.map(res => 
        res.id === reservationId 
          ? { ...res, status: 'accepted' as const }
          : res
      )
    );
    
    toast({
      title: "Reservation Accepted",
      description: "Customer has been notified that their reservation is ready",
    });
  };

  const handleMarkCollected = (reservationId: string) => {
    setReservations(prev => 
      prev.map(res => 
        res.id === reservationId 
          ? { ...res, status: 'collected' as const }
          : res
      )
    );
    
    toast({
      title: "Marked as Collected",
      description: "Reservation has been marked as collected",
    });
  };

  const handleCancel = (reservationId: string) => {
    setReservations(prev => 
      prev.map(res => 
        res.id === reservationId 
          ? { ...res, status: 'cancelled' as const }
          : res
      )
    );
    
    toast({
      title: "Reservation Cancelled",
      description: "Customer has been notified about the cancellation",
      variant: "destructive"
    });
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const isExpiringSoon = (expiresAt: string) => {
    const expiry = new Date(expiresAt);
    const now = new Date();
    const hoursUntilExpiry = (expiry.getTime() - now.getTime()) / (1000 * 60 * 60);
    return hoursUntilExpiry < 2 && hoursUntilExpiry > 0;
  };

  const activeReservations = reservations.filter(res => 
    res.status === 'pending' || res.status === 'accepted'
  );

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center space-x-4 mb-8">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/pharmacy/dashboard')}
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Dashboard</span>
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Reservation Requests</h1>
            <p className="text-muted-foreground">Manage customer medicine reservations</p>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="gradient-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Requests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {reservations.filter(r => r.status === 'pending').length}
              </div>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Accepted</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {reservations.filter(r => r.status === 'accepted').length}
              </div>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Collected Today</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {reservations.filter(r => r.status === 'collected').length}
              </div>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Expiring Soon</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-medicine-low">
                {reservations.filter(r => 
                  (r.status === 'pending' || r.status === 'accepted') && 
                  isExpiringSoon(r.expiresAt)
                ).length}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground">All Reservations</CardTitle>
          </CardHeader>
          
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Medicine</TableHead>
                    <TableHead>Brand & Strength</TableHead>
                    <TableHead>Qty</TableHead>
                    <TableHead>Reserved At</TableHead>
                    <TableHead>Expires At</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reservations.map((reservation) => {
                    const expiringSoon = isExpiringSoon(reservation.expiresAt);
                    
                    return (
                      <TableRow key={reservation.id}>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{reservation.customerName}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{reservation.customerPhone}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{reservation.medicine}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{reservation.brand}</div>
                            <div className="text-sm text-muted-foreground">{reservation.strength}</div>
                          </div>
                        </TableCell>
                        <TableCell>{reservation.quantity}</TableCell>
                        <TableCell className="text-sm">
                          {formatDateTime(reservation.reservedAt)}
                        </TableCell>
                        <TableCell className="text-sm">
                          <span className={expiringSoon ? 'text-medicine-low font-semibold' : ''}>
                            {formatDateTime(reservation.expiresAt)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getStatusVariant(reservation.status)}>
                            {reservation.status.charAt(0).toUpperCase() + reservation.status.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {reservation.status === 'pending' && (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleAccept(reservation.id)}
                                  className="h-8 text-xs"
                                >
                                  <Check className="h-3 w-3 mr-1" />
                                  Accept
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleCancel(reservation.id)}
                                  className="h-8 text-xs hover:bg-destructive hover:text-destructive-foreground"
                                >
                                  <X className="h-3 w-3 mr-1" />
                                  Cancel
                                </Button>
                              </>
                            )}
                            
                            {reservation.status === 'accepted' && (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleMarkCollected(reservation.id)}
                                  className="h-8 text-xs"
                                >
                                  <Check className="h-3 w-3 mr-1" />
                                  Collected
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleCancel(reservation.id)}
                                  className="h-8 text-xs hover:bg-destructive hover:text-destructive-foreground"
                                >
                                  <X className="h-3 w-3 mr-1" />
                                  Cancel
                                </Button>
                              </>
                            )}
                            
                            {(reservation.status === 'collected' || reservation.status === 'cancelled' || reservation.status === 'expired') && (
                              <span className="text-sm text-muted-foreground">No actions</span>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}