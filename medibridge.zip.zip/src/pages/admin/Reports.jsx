import { useState } from 'react';
import { SidebarProvider } from '@/components/ui/sidebar';
import { AdminSidebar } from '@/components/admin-sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BarChart3, 
  Download, 
  TrendingUp, 
  Search, 
  Calendar,
  FileText,
  Users,
  Store,
  Activity,
  Pill
} from 'lucide-react';

const topMedicines = [
  { name: "Paracetamol 500mg", searches: 1245, reservations: 456, growth: "+12%" },
  { name: "Amoxicillin 250mg", searches: 892, reservations: 234, growth: "+8%" },
  { name: "Omeprazole 20mg", searches: 756, reservations: 198, growth: "+15%" },
  { name: "Cetirizine 10mg", searches: 634, reservations: 176, growth: "+5%" },
  { name: "Ibuprofen 400mg", searches: 523, reservations: 145, growth: "+3%" },
  { name: "Metformin 500mg", searches: 445, reservations: 123, growth: "+18%" },
  { name: "Atorvastatin 20mg", searches: 387, reservations: 98, growth: "+7%" },
  { name: "Losartan 50mg", searches: 298, reservations: 87, growth: "+22%" }
];

const monthlyData = [
  { month: "Jan 2024", reservations: 1250, searches: 8950, pharmacies: 12 },
  { month: "Feb 2024", reservations: 1456, searches: 9870, pharmacies: 15 },
  { month: "Mar 2024", reservations: 1678, searches: 11200, pharmacies: 18 },
  { month: "Apr 2024", reservations: 1890, searches: 12400, pharmacies: 22 },
  { month: "May 2024", reservations: 2134, searches: 14500, pharmacies: 28 },
  { month: "Jun 2024", reservations: 2456, searches: 16800, pharmacies: 35 }
];

const reportsData = {
  totalReservations: "12,456",
  totalSearches: "89,420", 
  activePharmacies: "156",
  totalCustomers: "8,943",
  avgResponseTime: "2.4 min",
  successRate: "94.2%"
};

export default function Reports() {
  const [selectedTimeRange, setSelectedTimeRange] = useState("monthly");

  const downloadReport = (reportType) => {
    // Create sample CSV data based on report type
    let csvContent = "";
    let filename = "";

    switch (reportType) {
      case "medicines":
        csvContent = [
          "Medicine Name,Total Searches,Total Reservations,Growth Rate",
          ...topMedicines.map(m => `${m.name},${m.searches},${m.reservations},${m.growth}`)
        ].join('\n');
        filename = "top_medicines_report.csv";
        break;
      
      case "monthly":
        csvContent = [
          "Month,Reservations,Searches,New Pharmacies",
          ...monthlyData.map(d => `${d.month},${d.reservations},${d.searches},${d.pharmacies}`)
        ].join('\n');
        filename = "monthly_analytics_report.csv";
        break;
      
      case "summary":
        csvContent = [
          "Metric,Value",
          "Total Reservations," + reportsData.totalReservations,
          "Total Searches," + reportsData.totalSearches,
          "Active Pharmacies," + reportsData.activePharmacies,
          "Total Customers," + reportsData.totalCustomers,
          "Average Response Time," + reportsData.avgResponseTime,
          "Success Rate," + reportsData.successRate
        ].join('\n');
        filename = "platform_summary_report.csv";
        break;
      
      default:
        return;
    }

    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AdminSidebar />
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Reports & Analytics</h1>
            <p className="text-muted-foreground">Comprehensive platform insights and data exports</p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => downloadReport("summary")}>
              <Download className="h-4 w-4 mr-2" />
              Export Summary
            </Button>
            <Button onClick={() => downloadReport("monthly")}>
              <FileText className="h-4 w-4 mr-2" />
              Full Report
            </Button>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <Activity className="h-6 w-6 text-primary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">{reportsData.totalReservations}</p>
                <p className="text-xs text-muted-foreground">Total Reservations</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <Search className="h-6 w-6 text-accent mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">{reportsData.totalSearches}</p>
                <p className="text-xs text-muted-foreground">Total Searches</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <Store className="h-6 w-6 text-medicine-available mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">{reportsData.activePharmacies}</p>
                <p className="text-xs text-muted-foreground">Active Pharmacies</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <Users className="h-6 w-6 text-primary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">{reportsData.totalCustomers}</p>
                <p className="text-xs text-muted-foreground">Total Customers</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <Calendar className="h-6 w-6 text-accent mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">{reportsData.avgResponseTime}</p>
                <p className="text-xs text-muted-foreground">Avg Response Time</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <TrendingUp className="h-6 w-6 text-medicine-available mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">{reportsData.successRate}</p>
                <p className="text-xs text-muted-foreground">Success Rate</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="medicines" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="medicines">Top Medicines</TabsTrigger>
            <TabsTrigger value="analytics">Platform Analytics</TabsTrigger>
            <TabsTrigger value="exports">Data Exports</TabsTrigger>
          </TabsList>

          <TabsContent value="medicines" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <Pill className="h-5 w-5 text-primary" />
                  <span>Most Searched & Reserved Medicines</span>
                </CardTitle>
                <Button variant="outline" onClick={() => downloadReport("medicines")}>
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topMedicines.map((medicine, index) => (
                    <div key={medicine.name} className="flex items-center justify-between p-4 bg-muted/20 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-primary">#{index + 1}</span>
                        </div>
                        <div>
                          <h4 className="font-medium text-foreground">{medicine.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {medicine.searches} searches • {medicine.reservations} reservations
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="text-medicine-available">
                          {medicine.growth}
                        </Badge>
                        <p className="text-sm text-muted-foreground mt-1">Growth</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    <span>Monthly Trends</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {monthlyData.slice(-4).map((data) => (
                      <div key={data.month} className="flex items-center justify-between p-3 bg-muted/20 rounded">
                        <div>
                          <p className="font-medium text-foreground">{data.month}</p>
                          <p className="text-sm text-muted-foreground">{data.reservations} reservations</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">{data.searches} searches</p>
                          <p className="text-sm text-primary">+{data.pharmacies} pharmacies</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <span>Platform Performance</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 bg-muted/20 rounded">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Search Success Rate</span>
                        <span className="font-medium text-medicine-available">94.2%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-medicine-available h-2 rounded-full" style={{width: '94.2%'}}></div>
                      </div>
                    </div>
                    
                    <div className="p-3 bg-muted/20 rounded">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Reservation Completion</span>
                        <span className="font-medium text-primary">87.8%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{width: '87.8%'}}></div>
                      </div>
                    </div>
                    
                    <div className="p-3 bg-muted/20 rounded">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Pharmacy Response Rate</span>
                        <span className="font-medium text-accent">91.5%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-accent h-2 rounded-full" style={{width: '91.5%'}}></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="exports" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Medicine Reports</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Top searched medicines, reservation data, and trend analysis
                  </p>
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => downloadReport("medicines")}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download CSV
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Monthly Analytics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Monthly breakdown of reservations, searches, and pharmacy growth
                  </p>
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => downloadReport("monthly")}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download CSV
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Platform Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Overall platform metrics and key performance indicators
                  </p>
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => downloadReport("summary")}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download CSV
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Customer Data</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Customer registration trends and usage patterns
                  </p>
                  <Button className="w-full" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Download CSV
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pharmacy Performance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Individual pharmacy metrics and performance data
                  </p>
                  <Button className="w-full" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Download CSV
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Stock Reports</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Medicine availability and stock level reports across pharmacies
                  </p>
                  <Button className="w-full" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Download CSV
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}