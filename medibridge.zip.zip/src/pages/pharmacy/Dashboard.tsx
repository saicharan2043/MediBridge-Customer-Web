import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/Header';
import { Link } from 'react-router-dom';
import { 
  Package, 
  Clock, 
  AlertTriangle, 
  Plus, 
  List, 
  Users,
  TrendingUp,
  Calendar,
  Store
} from 'lucide-react';

export default function PharmacyDashboard() {
  const summaryData = {
    totalStock: 1247,
    todayReservations: 23,
    lowStockAlerts: 8,
    pendingRequests: 15
  };

  const recentReservations = [
    { id: '1', customer: 'John Doe', medicine: 'Paracetamol 500mg', time: '2 hours ago' },
    { id: '2', customer: 'Jane Smith', medicine: 'Aspirin 325mg', time: '3 hours ago' },
    { id: '3', customer: 'Mike Johnson', medicine: 'Ibuprofen 400mg', time: '5 hours ago' }
  ];

  const lowStockItems = [
    { name: 'Paracetamol 500mg', brand: 'Crocin', quantity: 5, minStock: 20 },
    { name: 'Aspirin 325mg', brand: 'Disprin', quantity: 3, minStock: 15 },
    { name: 'Vitamin D3', brand: 'Calcirol', quantity: 8, minStock: 25 }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="flex items-center space-x-2 mb-2">
            <Store className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">ABC Pharmacy Dashboard</h1>
          </div>
          <p className="text-muted-foreground">Welcome back! Here's what's happening at your pharmacy today.</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Stock Items</CardTitle>
              <Package className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{summaryData.totalStock}</div>
              <p className="text-xs text-muted-foreground">+12% from last month</p>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Today's Reservations</CardTitle>
              <Clock className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{summaryData.todayReservations}</div>
              <p className="text-xs text-muted-foreground">+5 from yesterday</p>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Low Stock Alerts</CardTitle>
              <AlertTriangle className="h-4 w-4 text-medicine-low" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-medicine-low">{summaryData.lowStockAlerts}</div>
              <p className="text-xs text-muted-foreground">Requires attention</p>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Requests</CardTitle>
              <Users className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{summaryData.pendingRequests}</div>
              <p className="text-xs text-muted-foreground">Awaiting response</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="gradient-card border-border mb-8">
          <CardHeader>
            <CardTitle className="text-foreground">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button asChild className="h-auto p-4 flex flex-col items-center space-y-2">
                <Link to="/pharmacy/add-stock">
                  <Plus className="h-6 w-6" />
                  <span>Add Stock</span>
                </Link>
              </Button>
              
              <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <Link to="/pharmacy/inventory">
                  <List className="h-6 w-6" />
                  <span>Manage Inventory</span>
                </Link>
              </Button>
              
              <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <Link to="/pharmacy/reservations">
                  <Calendar className="h-6 w-6" />
                  <span>View Reservations</span>
                </Link>
              </Button>
              
              <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <Link to="/pharmacy/analytics">
                  <TrendingUp className="h-6 w-6" />
                  <span>Analytics</span>
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Reservations */}
          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-foreground">Recent Reservations</CardTitle>
              <Button asChild variant="outline" size="sm">
                <Link to="/pharmacy/reservations">View All</Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentReservations.map((reservation) => (
                  <div key={reservation.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div>
                      <p className="font-medium text-foreground">{reservation.customer}</p>
                      <p className="text-sm text-muted-foreground">{reservation.medicine}</p>
                    </div>
                    <Badge variant="outline">{reservation.time}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Low Stock Items */}
          <Card className="gradient-card border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-foreground">Low Stock Items</CardTitle>
              <Button asChild variant="outline" size="sm">
                <Link to="/pharmacy/inventory">Manage</Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {lowStockItems.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div>
                      <p className="font-medium text-foreground">{item.brand}</p>
                      <p className="text-sm text-muted-foreground">{item.name}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant="destructive">{item.quantity} left</Badge>
                      <p className="text-xs text-muted-foreground mt-1">Min: {item.minStock}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}