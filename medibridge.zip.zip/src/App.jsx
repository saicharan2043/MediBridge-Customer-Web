import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LandingPage from "./pages/customer/LandingPage";
import SearchResults from "./pages/customer/SearchResults";
import MedicineDetails from "./pages/customer/MedicineDetails";
import ReserveMedicine from "./pages/customer/ReserveMedicine";
import ReservationConfirmation from "./pages/customer/ReservationConfirmation";
import SuggestBrand from "./pages/customer/SuggestBrand";
import CustomerDashboard from "./pages/customer/CustomerDashboard";
import Login from "./pages/customer/Login";
import PharmacyLogin from "./pages/pharmacy/Login";
import PharmacyDashboard from "./pages/pharmacy/Dashboard";
import AddStock from "./pages/pharmacy/AddStock";
import ManageInventory from "./pages/pharmacy/ManageInventory";
import ReservationRequests from "./pages/pharmacy/ReservationRequests";
import Analytics from "./pages/pharmacy/Analytics";
import AdminLogin from "./pages/admin/Login";
import AdminDashboard from "./pages/admin/Dashboard";
import ManagePharmacies from "./pages/admin/ManagePharmacies";
import ManageReservations from "./pages/admin/ManageReservations";
import MedicineMaster from "./pages/admin/MedicineMaster";
import Reports from "./pages/admin/Reports";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/search" element={<SearchResults />} />
          <Route path="/medicine/:id" element={<MedicineDetails />} />
          <Route path="/reserve/:id" element={<ReserveMedicine />} />
          <Route path="/reserved/:reservationId" element={<ReservationConfirmation />} />
          <Route path="/suggest-brand" element={<SuggestBrand />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<CustomerDashboard />} />
          <Route path="/pharmacy/login" element={<PharmacyLogin />} />
          <Route path="/pharmacy/dashboard" element={<PharmacyDashboard />} />
          <Route path="/pharmacy/add-stock" element={<AddStock />} />
          <Route path="/pharmacy/inventory" element={<ManageInventory />} />
          <Route path="/pharmacy/reservations" element={<ReservationRequests />} />
          <Route path="/pharmacy/analytics" element={<Analytics />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/pharmacies" element={<ManagePharmacies />} />
          <Route path="/admin/reservations" element={<ManageReservations />} />
          <Route path="/admin/medicines" element={<MedicineMaster />} />
          <Route path="/admin/reports" element={<Reports />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;