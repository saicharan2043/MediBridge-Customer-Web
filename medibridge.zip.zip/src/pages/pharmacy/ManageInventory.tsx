import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Header } from '@/components/Header';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Search, Edit, Trash2, Plus, Filter } from 'lucide-react';

interface StockItem {
  id: string;
  generic: string;
  brand: string;
  strength: string;
  quantity: number;
  expiryDate: string;
  batchNumber: string;
  costPrice: number;
  sellingPrice: number;
}

export default function ManageInventory() {
  const [searchTerm, setSearchTerm] = useState('');
  const [stockItems] = useState<StockItem[]>([
    {
      id: '1',
      generic: 'Paracetamol',
      brand: 'Crocin',
      strength: '500mg',
      quantity: 150,
      expiryDate: '2025-12-31',
      batchNumber: 'BT123456',
      costPrice: 8.50,
      sellingPrice: 12.00
    },
    {
      id: '2',
      generic: 'Aspirin',
      brand: 'Disprin',
      strength: '325mg',
      quantity: 3,
      expiryDate: '2025-06-15',
      batchNumber: 'BT789012',
      costPrice: 5.25,
      sellingPrice: 8.00
    },
    {
      id: '3',
      generic: 'Ibuprofen',
      brand: 'Brufen',
      strength: '400mg',
      quantity: 89,
      expiryDate: '2026-03-20',
      batchNumber: 'BT345678',
      costPrice: 15.75,
      sellingPrice: 22.00
    },
    {
      id: '4',
      generic: 'Vitamin D3',
      brand: 'Calcirol',
      strength: '2000IU',
      quantity: 8,
      expiryDate: '2025-09-10',
      batchNumber: 'BT901234',
      costPrice: 25.00,
      sellingPrice: 35.00
    },
    {
      id: '5',
      generic: 'Omeprazole',
      brand: 'Omez',
      strength: '20mg',
      quantity: 45,
      expiryDate: '2025-11-05',
      batchNumber: 'BT567890',
      costPrice: 12.30,
      sellingPrice: 18.00
    }
  ]);

  const navigate = useNavigate();
  const { toast } = useToast();

  const filteredItems = stockItems.filter(item =>
    item.generic.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.brand.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStockStatus = (quantity: number) => {
    if (quantity === 0) return { status: 'out', label: 'Out of Stock', variant: 'destructive' as const };
    if (quantity < 10) return { status: 'low', label: 'Low Stock', variant: 'secondary' as const };
    if (quantity < 20) return { status: 'medium', label: 'Medium', variant: 'outline' as const };
    return { status: 'good', label: 'Good Stock', variant: 'default' as const };
  };

  const handleEdit = (item: StockItem) => {
    toast({
      title: "Edit Stock",
      description: `Edit functionality for ${item.brand} ${item.strength}`,
    });
  };

  const handleDelete = (item: StockItem) => {
    toast({
      title: "Delete Stock",
      description: `Delete functionality for ${item.brand} ${item.strength}`,
      variant: "destructive"
    });
  };

  const isExpiringSoon = (expiryDate: string) => {
    const expiry = new Date(expiryDate);
    const today = new Date();
    const monthsUntilExpiry = (expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24 * 30);
    return monthsUntilExpiry < 6;
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/pharmacy/dashboard')}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Dashboard</span>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Manage Inventory</h1>
              <p className="text-muted-foreground">View and manage your pharmacy stock</p>
            </div>
          </div>
          
          <Button
            onClick={() => navigate('/pharmacy/add-stock')}
            className="gradient-primary text-primary-foreground flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add Stock</span>
          </Button>
        </div>

        <Card className="gradient-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-foreground">Stock Items</CardTitle>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by generic or brand name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-80"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Generic Name</TableHead>
                    <TableHead>Brand</TableHead>
                    <TableHead>Strength</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Batch No.</TableHead>
                    <TableHead>Cost Price</TableHead>
                    <TableHead>Selling Price</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => {
                    const stockStatus = getStockStatus(item.quantity);
                    const expiringSoon = isExpiringSoon(item.expiryDate);
                    
                    return (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.generic}</TableCell>
                        <TableCell>{item.brand}</TableCell>
                        <TableCell>{item.strength}</TableCell>
                        <TableCell>
                          <span className={item.quantity < 10 ? 'text-medicine-low font-semibold' : ''}>
                            {item.quantity}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant={stockStatus.variant}>
                            {stockStatus.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span className={expiringSoon ? 'text-medicine-out font-semibold' : ''}>
                            {new Date(item.expiryDate).toLocaleDateString()}
                          </span>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{item.batchNumber}</TableCell>
                        <TableCell>₹{item.costPrice.toFixed(2)}</TableCell>
                        <TableCell>₹{item.sellingPrice.toFixed(2)}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(item)}
                              className="h-8 w-8 p-0"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDelete(item)}
                              className="h-8 w-8 p-0 hover:bg-destructive hover:text-destructive-foreground"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
            
            {filteredItems.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No stock items found matching your search.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}